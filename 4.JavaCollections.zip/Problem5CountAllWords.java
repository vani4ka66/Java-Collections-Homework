import java.util.Scanner;

public class Problem5CountAllWords {
    public static void main(String[] args) {


        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();
        String[] integers = input.split("\\W+");

        System.out.println(integers.length);

    }
}
