import java.util.Scanner;

public class Problem2SequenceOfEqualStrings {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        String n = scan.nextLine();
        String[] line = n.split(" ");

        System.out.print(line[0] + " ");

        for (int i = 1; i < line.length; i++) {

            if (line[i].equals(line[i-1])){
                System.out.print(line[i] + " ");
            }
            else {
                System.out.println();
                System.out.print(line[i] + " ");
            }
        }

    }
}
