import java.util.Scanner;

public class Problem6CountSpecifiedWord {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine().toLowerCase();
        String command = scan.nextLine().toLowerCase();
        String[] line = input.split("\\W+");
        int count = 0;

        for (int i = 0; i < line.length; i++) {
            if (line[i].equals(command)){
                count++;
            }
        }
        System.out.println(count);

    }
}
