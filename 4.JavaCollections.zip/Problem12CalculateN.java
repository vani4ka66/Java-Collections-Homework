import java.util.Scanner;

public class Problem12CalculateN {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n = scan.nextInt();

        System.out.println(Factorial(n));
    }
    public  static  int Factorial(int n){

        if (n == 0){
            return 1;
        }
        else {
            return n* Factorial(n - 1);
        }
    }
}
